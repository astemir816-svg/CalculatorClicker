package com.example.calculator

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.ComponentName
import android.content.Context
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent

class ClickerAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile var instance: ClickerAccessibilityService? = null
            private set

        fun isEnabled(context: Context): Boolean {
            val expected = ComponentName(context, ClickerAccessibilityService::class.java).flattenToString()
            val enabled = Settings.Secure.getString(context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
            return enabled.split(':').any { it.equals(expected, ignoreCase = true) }
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    @Volatile private var clicking = false
    private var nextRunAt = 0L
    private var targetX = -1
    private var targetY = -1

    override fun onServiceConnected() { super.onServiceConnected(); instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() { stopClicking() }
    override fun onDestroy() { stopClicking(); if (instance === this) instance = null; super.onDestroy() }

    fun startClicking() {
        val prefs = getSharedPreferences("clicker", MODE_PRIVATE)
        targetX = prefs.getInt("point_x", -1)
        targetY = prefs.getInt("point_y", -1)
        if (targetX < 0 || targetY < 0) return
        clicking = true
        scheduleTap(0)
    }

    fun stopClicking() {
        clicking = false
        handler.removeCallbacksAndMessages(null)
    }

    fun isClicking() = clicking

    private fun scheduleTap(delay: Long) {
        if (!clicking) return
        handler.postDelayed({ performTap() }, delay)
    }

    private fun performTap() {
        if (!clicking) return
        val prefs = getSharedPreferences("clicker", MODE_PRIVATE)
        val cps = prefs.getInt("cps", 10).coerceIn(1, 30)
        val interval = 1000L / cps
        nextRunAt = android.os.SystemClock.elapsedRealtime() + interval
        val path = Path().apply { moveTo(targetX.toFloat(), targetY.toFloat()) }
        val stroke = GestureDescription.StrokeDescription(path, 0, 1)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        val accepted = dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                if (clicking) scheduleTap((nextRunAt - android.os.SystemClock.elapsedRealtime()).coerceAtLeast(0))
            }
            override fun onCancelled(gestureDescription: GestureDescription?) {
                if (clicking) scheduleTap((nextRunAt - android.os.SystemClock.elapsedRealtime()).coerceAtLeast(0))
            }
        }, null)
        if (!accepted && clicking) scheduleTap(interval)
    }
}
