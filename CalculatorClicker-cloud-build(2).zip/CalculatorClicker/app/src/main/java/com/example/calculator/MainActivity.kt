package com.example.calculator

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.graphics.Color
import android.widget.*

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var display: TextView
    private var expression = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showCalculator()
    }

    private fun baseLayout(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(20), dp(24), dp(20), dp(20))
        setBackgroundColor(Color.rgb(245, 246, 250))
    }

    private fun showCalculator() {
        root = baseLayout()
        root.addView(TextView(this).apply {
            text = "Калькулятор"
            textSize = 26f
            setTextColor(Color.rgb(30, 34, 48))
            gravity = Gravity.CENTER
        }, matchWrap())
        display = TextView(this).apply {
            text = "0"
            textSize = 34f
            gravity = Gravity.CENTER_VERTICAL or Gravity.END
            setTextColor(Color.BLACK)
            setPadding(dp(12), dp(18), dp(12), dp(18))
            setBackgroundColor(Color.WHITE)
        }
        root.addView(display, LinearLayout.LayoutParams(-1, dp(100)).apply { topMargin = dp(18); bottomMargin = dp(14) })
        val keys = listOf("7", "8", "9", "÷", "4", "5", "6", "×", "1", "2", "3", "−", "0", ".", "C", "+", "=")
        keys.chunked(4).forEach { rowKeys ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            rowKeys.forEach { key ->
                val b = Button(this).apply {
                    text = key
                    textSize = 20f
                    isAllCaps = false
                    setOnClickListener { pressKey(key) }
                }
                row.addView(b, LinearLayout.LayoutParams(0, dp(66), 1f).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) })
            }
            while (row.childCount < 4) row.addView(View(this), LinearLayout.LayoutParams(0, dp(66), 1f))
            root.addView(row)
        }
        setContentView(root)
    }

    private fun pressKey(key: String) {
        if (key == "C") { expression = ""; display.text = "0"; return }
        if (key == "=") { calculate(); return }
        expression += when (key) { "÷" -> "/"; "×" -> "*"; "−" -> "-"; else -> key }
        display.text = expression
        if (expression == "32233") {
            expression = ""
            showClickerSettings()
        }
    }

    private fun calculate() {
        try {
            val match = Regex("^(-?\\d+(?:\\.\\d+)?)([+*/-])(-?\\d+(?:\\.\\d+)?)$").matchEntire(expression)
            if (match != null) {
                val a = match.groupValues[1].toDouble()
                val b = match.groupValues[3].toDouble()
                val result = when (match.groupValues[2]) {
                    "+" -> a + b; "-" -> a - b; "*" -> a * b; "/" -> a / b; else -> 0.0
                }
                expression = if (result.isFinite()) result.toString().removeSuffix(".0") else "Ошибка"
                display.text = expression
            } else if (expression.isNotBlank()) {
                display.text = "Ошибка"
                expression = ""
            }
        } catch (_: Exception) { display.text = "Ошибка"; expression = "" }
    }

    private fun showClickerSettings() {
        root = baseLayout()
        root.addView(TextView(this).apply {
            text = "Настройки кликера"
            textSize = 25f
            setTextColor(Color.rgb(30, 34, 48))
        }, matchWrap())
        root.addView(TextView(this).apply { text = "Клики в секунду (CPS)"; textSize = 16f; setTextColor(Color.DKGRAY) }, marginParams(1, 18))
        val prefs = getSharedPreferences("clicker", MODE_PRIVATE)
        val cpsInput = EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setText(prefs.getInt("cps", 10).toString())
            hint = "1–30"
        }
        root.addView(cpsInput, LinearLayout.LayoutParams(-1, dp(54)))
        root.addView(TextView(this).apply { text = "Размер плавающей кнопки"; textSize = 16f; setTextColor(Color.DKGRAY) }, marginParams(1, 16))
        val sizeLabel = TextView(this).apply { text = "Размер: ${prefs.getInt("size", 64)} dp"; textSize = 15f; setTextColor(Color.DKGRAY) }
        root.addView(sizeLabel, matchWrap())
        val sizeSeek = SeekBar(this).apply {
            max = 96
            progress = (prefs.getInt("size", 64) - 40).coerceIn(0, 96)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { sizeLabel.text = "Размер: ${progress + 40} dp" }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        root.addView(sizeSeek, matchWrap())
        val pointStatus = TextView(this).apply {
            val x = prefs.getInt("point_x", -1); val y = prefs.getInt("point_y", -1)
            text = if (x >= 0 && y >= 0) "Точка выбрана: $x, $y" else "Точка на экране ещё не выбрана"
            textSize = 14f; setTextColor(Color.DKGRAY)
        }
        root.addView(pointStatus, marginParams(1, 14))
        addActionButton(root, "Выбрать точку на экране") {
            saveSettings(cpsInput.text.toString(), sizeSeek.progress + 40)
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                Toast.makeText(this, "Разреши отображение поверх других окон, затем снова нажми выбор точки", Toast.LENGTH_LONG).show()
            } else {
                val i = Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_PICK_POINT)
                startOverlayService(i)
                Toast.makeText(this, "Вернись в Minecraft и коснись нужного места на экране", Toast.LENGTH_LONG).show()
            }
        }
        addActionButton(root, "Включить плавающую кнопку") {
            val cps = saveSettings(cpsInput.text.toString(), sizeSeek.progress + 40)
            if (cps == null) return@addActionButton
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                Toast.makeText(this, "Сначала разреши отображение поверх других окон", Toast.LENGTH_LONG).show()
            } else if (!ClickerAccessibilityService.isEnabled(this)) {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                Toast.makeText(this, "Включи службу «Кликер калькулятора», затем вернись сюда", Toast.LENGTH_LONG).show()
            } else {
                startOverlayService(Intent(this, OverlayService::class.java))
                Toast.makeText(this, "Плавающая кнопка включена", Toast.LENGTH_SHORT).show()
            }
        }
        addActionButton(root, "Выключить кликер и закрыть кнопку") {
            stopService(Intent(this, OverlayService::class.java))
            Toast.makeText(this, "Кликер остановлен", Toast.LENGTH_SHORT).show()
        }
        addActionButton(root, "Полностью закрыть приложение") {
            stopService(Intent(this, OverlayService::class.java))
            finishAndRemoveTask()
        }
        addActionButton(root, "Назад к калькулятору") { showCalculator() }
        setContentView(root)
    }

    private fun saveSettings(rawCps: String, size: Int): Int? {
        val cps = rawCps.toIntOrNull()
        if (cps == null || cps !in 1..30) {
            Toast.makeText(this, "Укажи CPS от 1 до 30", Toast.LENGTH_SHORT).show()
            return null
        }
        getSharedPreferences("clicker", MODE_PRIVATE).edit().putInt("cps", cps).putInt("size", size).apply()
        return cps
    }

    private fun startOverlayService(intent: Intent) {
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
    }

    private fun addActionButton(parent: LinearLayout, label: String, action: () -> Unit) {
        parent.addView(Button(this).apply { text = label; isAllCaps = false; setOnClickListener { action() } }, marginParams(1, 8))
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)
    private fun marginParams(weight: Int, top: Int) = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(top) }
}
