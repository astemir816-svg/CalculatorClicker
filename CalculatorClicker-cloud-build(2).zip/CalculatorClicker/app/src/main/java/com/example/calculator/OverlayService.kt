package com.example.calculator

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast

class OverlayService : Service() {
    companion object {
        const val ACTION_PICK_POINT = "com.example.calculator.PICK_POINT"
        private const val CHANNEL_ID = "clicker_overlay"
        private const val NOTIFICATION_ID = 32233
    }

    private lateinit var windowManager: WindowManager
    private var floatingButton: TextView? = null
    private var floatingParams: WindowManager.LayoutParams? = null
    private var pickerView: FrameLayout? = null
    private var pickerParams: WindowManager.LayoutParams? = null
    private var pickerConfirmView: TextView? = null
    private var pickerConfirmParams: WindowManager.LayoutParams? = null
    private var pickerDownX = 0f
    private var pickerDownY = 0f
    private var pickerInitialX = 0
    private var pickerInitialY = 0
    private var moved = false
    private var downX = 0f
    private var downY = 0f
    private var initialX = 0
    private var initialY = 0

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification())
        showFloatingButton()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_PICK_POINT) showPointPicker()
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun showFloatingButton() {
        if (floatingButton != null || !android.provider.Settings.canDrawOverlays(this)) return
        val density = resources.displayMetrics.density
        val sizeDp = getSharedPreferences("clicker", MODE_PRIVATE).getInt("size", 64).coerceIn(40, 136)
        val sizePx = (sizeDp * density).toInt()
        val button = TextView(this).apply {
            text = "▶"
            textSize = 23f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.rgb(63, 81, 181)); setStroke((2 * density).toInt(), Color.WHITE) }
            contentDescription = "Запустить или остановить кликер; удерживай и перетаскивай для перемещения"
        }
        val params = WindowManager.LayoutParams(sizePx, sizePx, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = 30; y = 220 }
        button.setOnTouchListener { view, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    moved = false; downX = event.rawX; downY = event.rawY
                    initialX = params.x; initialY = params.y; true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downX).toInt(); val dy = (event.rawY - downY).toInt()
                    if (kotlin.math.abs(dx) > 5 || kotlin.math.abs(dy) > 5) moved = true
                    if (moved) { params.x = initialX + dx; params.y = initialY + dy; windowManager.updateViewLayout(view, params) }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) toggleClicking(view as TextView)
                    true
                }
                else -> true
            }
        }
        try { windowManager.addView(button, params); floatingButton = button; floatingParams = params }
        catch (_: Exception) { Toast.makeText(this, "Не удалось показать плавающую кнопку", Toast.LENGTH_LONG).show() }
    }

    private fun toggleClicking(button: TextView) {
        val service = ClickerAccessibilityService.instance
        if (service == null) {
            Toast.makeText(this, "Сначала включи службу кликера в настройках специальных возможностей", Toast.LENGTH_LONG).show()
            return
        }
        if (service.isClicking()) {
            service.stopClicking(); button.text = "▶"
        } else {
            val prefs = getSharedPreferences("clicker", MODE_PRIVATE)
            if (prefs.getInt("point_x", -1) < 0 || prefs.getInt("point_y", -1) < 0) {
                Toast.makeText(this, "Сначала выбери точку на экране", Toast.LENGTH_SHORT).show(); return
            }
            service.startClicking(); button.text = "■"
        }
    }

    private fun showPointPicker() {
        if (pickerView != null || !android.provider.Settings.canDrawOverlays(this)) return
        val density = resources.displayMetrics.density
        val targetSize = (58 * density).toInt()
        val target = FrameLayout(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xCC202124.toInt())
                setStroke((2 * density).toInt(), Color.WHITE)
            }
            addView(TextView(this@OverlayService).apply {
                text = "✥"
                textSize = 30f
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
            }, FrameLayout.LayoutParams(-1, -1))
            contentDescription = "Перетащи прицел на нужную точку Minecraft"
        }
        val targetParams = WindowManager.LayoutParams(
            targetSize, targetSize, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (resources.displayMetrics.widthPixels / 2) - targetSize / 2
            y = (resources.displayMetrics.heightPixels / 2) - targetSize / 2
        }
        target.setOnTouchListener { view, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    pickerDownX = event.rawX
                    pickerDownY = event.rawY
                    pickerInitialX = targetParams.x
                    pickerInitialY = targetParams.y
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    targetParams.x = pickerInitialX + (event.rawX - pickerDownX).toInt()
                    targetParams.y = pickerInitialY + (event.rawY - pickerDownY).toInt()
                    try { windowManager.updateViewLayout(view, targetParams) } catch (_: Exception) {}
                    true
                }
                else -> true
            }
        }

        val confirm = TextView(this).apply {
            text = "✓"
            textSize = 27f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.rgb(46, 125, 50))
                setStroke((2 * density).toInt(), Color.WHITE)
            }
            contentDescription = "Подтвердить выбранную точку"
            setOnClickListener {
                val location = IntArray(2)
                target.getLocationOnScreen(location)
                val x = location[0] + target.width / 2
                val y = location[1] + target.height / 2
                getSharedPreferences("clicker", MODE_PRIVATE).edit()
                    .putInt("point_x", x).putInt("point_y", y).apply()
                Toast.makeText(this, "Точка сохранена: $x, $y", Toast.LENGTH_SHORT).show()
                removePicker()
                showFloatingButton()
            }
        }
        val confirmParams = WindowManager.LayoutParams(
            targetSize, targetSize, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (resources.displayMetrics.widthPixels - targetSize - (16 * density).toInt()).coerceAtLeast(0)
            y = (80 * density).toInt()
        }
        try {
            windowManager.addView(target, targetParams)
            pickerView = target
            pickerParams = targetParams
            windowManager.addView(confirm, confirmParams)
            pickerConfirmView = confirm
            pickerConfirmParams = confirmParams
            Toast.makeText(this, "Перетащи прицел на кнопку Minecraft и нажми ✓", Toast.LENGTH_LONG).show()
        } catch (_: Exception) {
            removePicker()
            Toast.makeText(this, "Не удалось открыть выбор точки", Toast.LENGTH_LONG).show()
        }
    }

    private fun removePicker() {
        pickerView?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        pickerConfirmView?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        pickerView = null
        pickerParams = null
        pickerConfirmView = null
        pickerConfirmParams = null
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL_ID, "Плавающий кликер", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL_ID) else Notification.Builder(this)
        return builder.setContentTitle("Калькулятор — кликер активен")
            .setContentText("Нажми плавающую кнопку, чтобы запустить или остановить клики")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true).build()
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        ClickerAccessibilityService.instance?.stopClicking()
        stopSelf()
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        ClickerAccessibilityService.instance?.stopClicking()
        removePicker()
        floatingButton?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        floatingButton = null
        super.onDestroy()
    }
}
